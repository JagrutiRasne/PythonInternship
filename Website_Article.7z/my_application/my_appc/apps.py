from django.apps import AppConfig


class MyAppcConfig(AppConfig):
    name = 'my_appc'

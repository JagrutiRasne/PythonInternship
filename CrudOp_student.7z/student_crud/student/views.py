from django.shortcuts import render, redirect  
from student.forms import StudentForm  
from student.models import Student
# Create your views here.


def home(request):
    return render(request,'home.html')
   


def stu(request):  
    if request.method == "POST":  
        form = StudentForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return redirect('/show')  
            except:  
                pass  
    else:  
        form = StudentForm()  
    return render(request,'index.html',{'form':form})  
def show(request):  
    students = Student.objects.all()  
    return render(request,"show.html",{'students':students})  
def edit(request, id):
    s1 = Student.objects.get(id=id)  
    return render(request,'edit.html', {'s1':s1})  
def update(request, id):  
    students = Student.objects.get(id=id)  
    form = StudentForm(request.POST, instance = students)  
    if form.is_valid():  
        form.save()  
        return redirect("/show")  
    return render(request, 'edit.html', {'students': students})  
def destroy(request, id):  
    s1 = Student.objects.get(id=id)  
    s1.delete()  
    return redirect("/show")